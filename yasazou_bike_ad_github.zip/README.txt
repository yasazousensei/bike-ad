# やさぞう先生｜バイク広告募集ページ

GitHub Pagesで公開できる1ページ完結型の広告主募集ページです。

## 公開前に必ずすること
`index.html` の下部にある

`const CONTACT_EMAIL = "ここに受信先メールアドレスを入れてください";`

を、実際に申し込みを受け取るメールアドレスへ変更してください。

## GitHub Pages
1. GitHubで新しいRepositoryを作る
2. `index.html` と3枚の画像をアップロード
3. Settings → Pages
4. Branchを `main` / `root` にして保存
5. 表示されたURLを広告募集ページとして使用

## 注意
このフォームは静的サイト用で、送信時に利用者のメールアプリを開く方式です。
